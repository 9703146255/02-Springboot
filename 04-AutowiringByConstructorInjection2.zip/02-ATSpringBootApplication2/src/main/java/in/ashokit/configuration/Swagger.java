package in.ashokit.configuration;

public class Swagger 
{
  public Swagger() 
  {
	  System.out.println("Swagger() :: constructor");
  }
}
