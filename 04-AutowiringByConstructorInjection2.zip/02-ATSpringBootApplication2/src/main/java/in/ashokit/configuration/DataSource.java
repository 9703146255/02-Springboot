package in.ashokit.configuration;

public class DataSource
{
	public DataSource()
	{
		System.out.println("DataSource() :: Constructor");
	}
	
	
	
	
}
