package in.ashokit.configuration;

public class Kafka {
	
	
	public Kafka() {
		System.out.println("Kafka() :: Constructor");
	}

}
