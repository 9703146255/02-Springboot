package in.ashokit.configuration;

public class Redis {

	public Redis() {

		System.out.println(" Redis() :: Constructor ..");
	}

}
