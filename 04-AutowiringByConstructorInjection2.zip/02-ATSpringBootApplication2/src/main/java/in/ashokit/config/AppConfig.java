package in.ashokit.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import in.ashokit.configuration.DataSource;
import in.ashokit.configuration.Kafka;
import in.ashokit.configuration.Redis;
import in.ashokit.configuration.Swagger;
import in.ashokit.security.AppSecurity;

@Configuration
public class AppConfig {

	public AppConfig() {
		System.out.println("AppConfig :: Constructor...");
	}

    @Bean
    AppSecurity getConfigurationObj() {
		AppSecurity securityObj = new AppSecurity();

		return securityObj;
	}

    @Bean
    Kafka getKafkaConigObj() {

		Kafka kafkaObj = new Kafka();

		return kafkaObj;

	}

    @Bean
    DataSource getDataSourceObj() {

		DataSource dsObj = new DataSource();

		return dsObj;

	}

    @Bean
    Redis getRediObj() {

		Redis rdObj=new Redis();
		 return rdObj;

	}

    @Bean
    Swagger getSwaggerObj()
	{
		Swagger swObj=new Swagger();
		
		return swObj;
	}
	
	
	

}
