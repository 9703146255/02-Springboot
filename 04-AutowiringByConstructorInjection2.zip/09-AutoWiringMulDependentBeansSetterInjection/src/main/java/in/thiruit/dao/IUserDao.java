package in.thiruit.dao;

public interface IUserDao {

	public boolean saveUser(String userName, String userEmail, String userPwd);

}
