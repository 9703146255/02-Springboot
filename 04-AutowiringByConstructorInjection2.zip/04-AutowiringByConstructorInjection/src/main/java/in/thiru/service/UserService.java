package in.thiru.service;

import org.springframework.stereotype.Component;

import in.thiru.dao.UserDao;


/*
 
 
 ==>	without using annotation also it will perform teh dependcy injection here 
 
 ==>	when we have only one parameteraized constructor
 
 ==>	When we have two type of constructor IOC get to interact with 0-PARAM constructor
 
 ==>	When we have only one parameteraized constructor then @Autowired is optional
 
 
public UserService(){}
public UserService(UserDao dao){this.dao=dao;}
 */
@Component
public class UserService 
{
	private UserDao dao;

	public UserService()
	{
		System.out.println("UserService :: 0-Param Constructor ");
	}
	
	public UserService(UserDao dao)
	{
		System.out.println("UserService :: 0-Param Constructor ");
		this.dao=dao;
	}
	
	public void printNameById(Integer id)
	{
		String name = dao.findNameById(id);
		System.out.println("name of the user is :: "+name);
		
	}
	
	
	
}
