package in.ashokit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(Application.class, args);
		//System.out.println(run.getClass().getName());
		System.out.println("total number of classes is loading in my spring boot app :	"+run.getBeanDefinitionCount());
		System.out.println(run.getBeanDefinitionNames());
		
		
	}

}
