package in.ashokit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import in.ashokit.security.AppSecurity;

@SpringBootApplication
@ComponentScan(basePackages = {"in.ashokit","com.tcs","win.thiru"})
public class Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(Application.class, args);
		
		//ReportDAO bean = run.getBean(ReportDAO.class);
		
		System.out.println("no of beans loaded is :: " +run.getBeanDefinitionCount());
		
		
	}
	
	
	@Bean
	public AppSecurity getConfigurationObj()
	{
	  AppSecurity security=new AppSecurity();
				
	   return security;
	}
	

}
