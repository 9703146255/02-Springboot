package in.ashokit.security;

import org.springframework.stereotype.Component;

//@Component
public class AppSecurity 
{

	public AppSecurity() 
	{
		
		System.out.println("AppSecurity :: Constructor...");
	}
	
	
}
