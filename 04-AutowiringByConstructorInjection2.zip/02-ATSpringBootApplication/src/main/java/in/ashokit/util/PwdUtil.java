package in.ashokit.util;

import org.springframework.stereotype.Component;

@Component
public class PwdUtil {
	
	public PwdUtil() {
		
		System.out.println("PwdUtil :: COnstructor");
	}

}
