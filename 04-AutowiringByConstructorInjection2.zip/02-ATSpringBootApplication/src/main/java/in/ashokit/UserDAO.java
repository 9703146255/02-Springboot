package in.ashokit;

import org.springframework.stereotype.Component;

@Component
public class UserDAO {
	public UserDAO() 
	{
		System.out.println("UserDAO :: Constructor...");
	}

}
