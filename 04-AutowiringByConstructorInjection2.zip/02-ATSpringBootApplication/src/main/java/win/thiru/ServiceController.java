package win.thiru;

import org.springframework.stereotype.Component;

@Component
public class ServiceController {

	public ServiceController() {
		System.out.println("ServiceController:: Constructor");
	}
}
