package com.tcs;

import org.springframework.stereotype.Component;

@Component
public class ReportService 
{

	public ReportService() {
		System.out.println("ReportService :: Constructor");
	}
	
	
}
