package com.tcs;

import org.springframework.stereotype.Component;

@Component
public class UserService 
{
	public UserService() 
	{
		System.out.println("UserService :: Constructor");
	}
}
