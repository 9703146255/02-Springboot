package in.thiru.dao;

public interface UserDao 
{

	public String  findNameById(Integer id);
	
	
	
	
}
