package in.thiruit.utility;

import org.springframework.stereotype.Component;

@Component
public class PasswordEncryption {

	public boolean getPasswordEncryption(String pwd) {

		System.out.println("password encrypter ......");

		return true;
	}

}
